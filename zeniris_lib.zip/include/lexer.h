#ifndef LEXER_H
#define LEXER_H

#include "token.h"

#define MAX_TOKENS 8192   /* aumentado de 4096 — projetos grandes */

typedef struct {
    Token tokens[MAX_TOKENS];
    int   count;
    int   erros;
    int   overflow;   /* 1 se MAX_TOKENS foi atingido */
} ResultadoLex;

ResultadoLex zeniris_lexar(const char* codigo);

#endif
