#ifndef PARSER_H
#define PARSER_H

#include "lexer.h"

#define MAX_DEPS       16
#define MAX_RESTRICOES 64
#define MAX_CORPO      256
#define MAX_FUNCTIONS  64
#define MAX_EVENTOS    64
#define MAX_CLASSES    16
#define MAX_VARIAVEIS  128
#define MAX_IMPORTS    32
#define MAX_SE_CORPO   32

typedef struct {
    char expressao[256];
    char vinculo[256];
    int  eh_estado_check;
} NoRestricao;

typedef struct {
    char alvo[256];
    char valor[256];
    int  eh_multi_estado;
} NoAtribuicao;

typedef struct {
    char         condicao[256];
    NoAtribuicao entao[MAX_SE_CORPO];
    int          n_entao;
    NoAtribuicao senao[MAX_SE_CORPO];
    int          n_senao;
} NoSe;

typedef enum { CORPO_ATRIB, CORPO_SE } TipoCorpo;

typedef struct {
    TipoCorpo    tipo;
    NoAtribuicao atrib;
    NoSe         se;
} NoCorpo;

typedef struct {
    char      nome[256];
    char      deps[MAX_DEPS][256];
    int       n_deps;
    NoRestricao restricoes[MAX_RESTRICOES];
    int       n_restricoes;
    NoCorpo   corpo[MAX_CORPO];
    int       n_corpo;
} NoFunction;

typedef struct {
    char    nome[256];
    NoCorpo corpo[MAX_CORPO];
    int     n_corpo;
} NoEvento;

typedef struct {
    char      nome[256];
    NoFunction* functions[MAX_FUNCTIONS];
    int         n_functions;
    NoEvento*   eventos[MAX_EVENTOS];
    int         n_eventos;
} NoClasse;

/* variavel simples: guarda a string raw como vinha no 0.2.0 */
typedef struct {
    char nome[256];
} NoVariavel;

typedef struct {
    char       imports[MAX_IMPORTS][256];
    int        n_imports;
    NoVariavel variaveis[MAX_VARIAVEIS];
    int        n_variaveis;
    NoClasse*  classes[MAX_CLASSES];
    int        n_classes;
    int        erro;
    char       msg_erro[512];
} NoPrograma;

NoPrograma* zeniris_parsear(ResultadoLex* lex);
void        zeniris_programa_free(NoPrograma* prog);

#endif
