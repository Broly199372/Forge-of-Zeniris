#ifndef RUNTIME_H
#define RUNTIME_H

#include "parser.h"

#define MAX_PARES 512

typedef struct { char chave[256]; char valor[256]; } Par;

typedef struct {
    Par         variaveis[MAX_PARES];
    int         n_variaveis;
    Par         estados[MAX_PARES];
    int         n_estados;
    NoPrograma* prog;
} Runtime;

void  rt_init(Runtime* rt, NoPrograma* prog);
void  rt_set_var(Runtime* rt, const char* nome, const char* valor);
char* rt_get_var(Runtime* rt, const char* nome);
void  rt_set_estado(Runtime* rt, const char* chave, const char* valor);
char* rt_get_estado(Runtime* rt, const char* chave);
int   rt_executar_function(Runtime* rt, const char* nome);
void  rt_disparar_evento(Runtime* rt, const char* nome);
void  rt_dump(Runtime* rt);

/* imports — declaracao DENTRO do guard para evitar double declaration */
void rt_carregar_import(Runtime* rt, Runtime* outro);

#endif
