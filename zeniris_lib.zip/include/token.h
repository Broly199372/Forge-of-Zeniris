#ifndef TOKEN_H
#define TOKEN_H

typedef enum {
    TOK_INICIO,
    TOK_FIM,
    TOK_IMPORTS,
    TOK_VARIAVEL,
    TOK_CLASSE,
    TOK_FUNCTION,
    TOK_RESTRICOES,
    TOK_EVENTO_INICIO,
    TOK_EVENTO_FIM,
    TOK_OBSERVAR,
    TOK_COMPARADOR,
    TOK_ATRIBUICAO,
    TOK_IDENTIFICADOR,
    TOK_ABRE_PAREN,
    TOK_FECHA_PAREN,
    TOK_VIRGULA,
    TOK_PONTO,
    TOK_ON_DEPS,
    TOK_ESTADO_CHECK,   /* Entidade.Estado on/off             */
    TOK_MULTI_ESTADO,   /* Entidade(E1.E2, on1)               */
    TOK_SE,
    TOK_SENAO,
    /* sintaxe turbo (plano.txt) */
    TOK_TIL,            /* ~ negacao                          */
    TOK_EXEC,           /* ! execucao direta                  */
    TOK_ARROW_FWD,      /* >> transicao direta                */
    TOK_ARROW_BWD,      /* << transicao reversa               */
    TOK_MOREQ,          /* => maior ou igual turbo            */
    TOK_CONTEXTO,       /* Contexto NomeCtx :                 */
    TOK_CONTEXTO_FIM,   /* : (fecha bloco Contexto)           */
    /* loops nativos */
    TOK_PARA,           /* Para / For / Para                  */
    TOK_ENQUANTO,       /* Enquanto / While / Mientras        */
    TOK_ATE,            /* ate / to / hasta                   */
    TOK_FACA,           /* Faca / Do / Haz                    */
    TOK_ERRO,
    TOK_EOF
} TipoToken;

typedef struct {
    TipoToken tipo;
    char      valor[256];
    int       linha;
} Token;

const char* token_nome(TipoToken t);

#endif
