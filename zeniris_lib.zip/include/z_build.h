#ifndef Z_BUILD_H
#define Z_BUILD_H

#include "parser.h"
#include "zeniris_erro.h"

typedef struct {
    int   total;
    int   erros;
    int   avisos;
    char  relatorio[4096];
} ZBuildResultado;

ZBuildResultado z_build_validar(NoPrograma* prog, const char* arquivo, Idioma lang);

#endif
