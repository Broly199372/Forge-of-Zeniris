#ifndef Z_PACK_H
#define Z_PACK_H

#include "parser.h"
#include "zeniris_erro.h"

/*
 * Formato ZNI (Zeniris Native Image)
 *
 * [HEADER]
 *   magic:    4 bytes  "ZNI\0"
 *   version:  1 byte   0x01
 *   idioma:   1 byte   0=PT 1=EN 2=ES
 *   n_import: 2 bytes
 *   n_vars:   2 bytes
 *   n_classes:2 bytes
 *
 * [IMPORTS]  n_import * 256 bytes
 * [VARIAVEIS] n_vars * 256 bytes
 * [CLASSES]
 *   nome: 256 bytes
 *   n_functions: 2 bytes
 *   n_eventos:   2 bytes
 *   [FUNCTIONS]
 *     nome:        256 bytes
 *     n_deps:      2 bytes
 *     n_restricoes:2 bytes
 *     n_corpo:     2 bytes
 *     deps:        n_deps * 256
 *     restricoes:  n_restricoes * (256+256)
 *     corpo:       n_corpo * (256+256)
 *   [EVENTOS]
 *     nome:    256 bytes
 *     n_corpo: 2 bytes
 *     corpo:   n_corpo * (256+256)
 */

#define ZNI_MAGIC "ZNI"

/* FIX #9: sem packed o compilador insere padding entre os campos,
 * fazendo fwrite/fread do header ser inconsistente entre plataformas
 * (ex: ARM vs x86, GCC vs Clang). packed garante layout exato de 12 bytes. */
#ifdef _MSC_VER
#pragma pack(push, 1)
#endif
typedef struct {
    char magic[4];
    unsigned char version;
    unsigned char idioma;
    unsigned short n_imports;
    unsigned short n_variaveis;
    unsigned short n_classes;
}
#ifdef __GNUC__
__attribute__((packed))
#endif
ZniHeader;
#ifdef _MSC_VER
#pragma pack(pop)
#endif

int  zni_empacotar(NoPrograma* prog, Idioma lang, const char* saida);
int  zni_desempacotar(const char* arquivo, NoPrograma* prog_out, Idioma* lang_out);
void zni_info(const char* arquivo);

#endif
