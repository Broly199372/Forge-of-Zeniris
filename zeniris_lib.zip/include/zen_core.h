#ifndef ZEN_CORE_H
#define ZEN_CORE_H

#include "runtime.h"

/* Zen Core — biblioteca nativa da Zeniris */
void zen_log(const char* msg);
void zen_log_estado(Runtime* rt);
long zen_tempo_ms(void);
void zen_aguardar_ms(long ms);
int  zen_estado_mudou(Runtime* rt, const char* chave, const char* valor_anterior);

#endif
