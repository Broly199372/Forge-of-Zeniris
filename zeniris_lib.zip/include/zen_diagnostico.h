#ifndef ZEN_DIAGNOSTICO_H
#define ZEN_DIAGNOSTICO_H

#include "zeniris_erro.h"

typedef struct {
    int n_erros;
    int n_avisos;
} ZenDiagnostico;

ZenDiagnostico zen_diagnosticar(const char* arquivo);

#endif
