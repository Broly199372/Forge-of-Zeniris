#ifndef ZEN_ENGINE_H
#define ZEN_ENGINE_H

#include "runtime.h"
#include "zen_loop.h"
#include "zen_modulo.h"
#include "zen_observar.h"
#include "zeniris_erro.h"

#define ZEN_ENGINE_VERSAO "0.1.0"

typedef struct {
    Runtime          rt;
    ZenLoop          loop;
    ZenModuloManager zmm;
    ZenObserver      observer;
    Idioma           lang;
    int              iniciado;
} ZenEngine;

void zen_engine_init(ZenEngine* engine, int fps_alvo);
int  zen_engine_carregar(ZenEngine* engine, const char* arquivo_zr_ou_zni);
void zen_engine_rodar(ZenEngine* engine);
void zen_engine_parar(ZenEngine* engine);
void zen_engine_dump(ZenEngine* engine);

#endif
