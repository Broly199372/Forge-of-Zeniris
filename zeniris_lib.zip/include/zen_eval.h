#ifndef ZEN_EVAL_H
#define ZEN_EVAL_H

/*
 * zen_eval.h — Avaliador de expressões Zeniris
 * =============================================
 * Versão corrigida: suporta associatividade correta,
 * resultados booleanos tipados e operadores turbo (>=, <=, !=, ~).
 */

#include "zen_tipos.h"

typedef struct {
    double valor;
    int    ok;
    int    is_bool;   /* 1 se o resultado é booleano (comparação) */
    char   erro[256];
} ZEvalResult;

ZEvalResult zen_eval(ZVarTable* t, const char* expr);
int         zen_eval_atribuir(ZVarTable* t, const char* nome, const char* expr);

#endif
