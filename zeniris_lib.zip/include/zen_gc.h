#ifndef ZEN_GC_H
#define ZEN_GC_H

/*
 * zen_gc — Garbage Collector simples de referencia para a Zeniris.
 *
 * Funciona como um pool de ponteiros rastreados:
 *   - zen_gc_registrar(ptr)  : registra um ponteiro alocado
 *   - zen_gc_liberar(ptr)    : libera um ponteiro especifico e remove do pool
 *   - zen_gc_coletar()       : libera TUDO que foi registrado (fim de programa)
 *   - zen_gc_dump()          : imprime o estado atual do pool (debug)
 *
 * Uso tipico:
 *   NoPrograma* prog = zeniris_parsear(&lex);
 *   zen_gc_registrar(prog);
 *   // ... usa prog normalmente ...
 *   zen_gc_coletar(); // libera tudo ao final — sem free manual
 *
 * Nao e thread-safe. Para uso single-thread (runtime da Zeniris).
 */

#define ZEN_GC_MAX 1024  /* maximo de ponteiros rastreados simultaneamente */

typedef void (*ZenGCDestrutor)(void* ptr);

typedef struct {
    void*         ptr;
    ZenGCDestrutor destrutor; /* NULL = usa free() padrao */
} ZenGCEntrada;

/* Inicializa o GC (chamado automaticamente na primeira operacao) */
void zen_gc_init(void);

/*
 * Registra um ponteiro para ser gerenciado pelo GC.
 * destrutor: funcao chamada para liberar o ponteiro.
 *            passe NULL para usar free() simples.
 *            passe zeniris_programa_free para NoPrograma*.
 */
void zen_gc_registrar(void* ptr, ZenGCDestrutor destrutor);

/* Libera um ponteiro especifico imediatamente e remove do pool */
void zen_gc_liberar(void* ptr);

/* Libera todos os ponteiros registrados (fim de programa/escopo) */
void zen_gc_coletar(void);

/* Imprime o estado do pool para debug */
void zen_gc_dump(void);

/* Retorna quantos ponteiros estao atualmente rastreados */
int zen_gc_contagem(void);

#endif
