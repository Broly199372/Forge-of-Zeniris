#ifndef ZEN_LOOP_H
#define ZEN_LOOP_H

#include "runtime.h"

#define ZEN_LOOP_FPS_PADRAO 60

typedef struct {
    int    fps_alvo;
    double delta;
    long   frame;
    long   tempo_total_ms;
    int    rodando;
} ZenLoop;

typedef void (*ZenLoopCallback)(ZenLoop* loop, Runtime* rt, double delta);

void zen_loop_init(ZenLoop* loop, int fps_alvo);
void zen_loop_rodar(ZenLoop* loop, Runtime* rt, ZenLoopCallback on_update);
void zen_loop_parar(ZenLoop* loop);

#endif
