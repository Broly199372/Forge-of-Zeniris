#ifndef ZEN_LOOP_SYNTAX_H
#define ZEN_LOOP_SYNTAX_H

#include "zen_tipos.h"

typedef void (*ZLoopCallback)(int iteracao, void* ctx);

/*
 * zen_repetir — repete N vezes (N avaliado via zen_eval).
 *   ex Zeniris:  Para i = 0 ate 10 Faca
 */
void zen_repetir(ZVarTable* t, const char* expr_vezes,
                 ZLoopCallback cb, void* ctx);

/*
 * zen_enquanto — loop condicional.
 *   ex Zeniris:  Enquanto vida > 0 Faca
 */
void zen_enquanto(ZVarTable* t, const char* var, const char* op,
                  const char* val, ZLoopCallback cb, void* ctx);

/*
 * zen_para — loop Para i = inicio ate fim com passo opcional.
 *   passo = 0 usa padrao 1 (ou -1 se fim < inicio).
 *   ex Zeniris:  Para i = 1 ate 5 Faca / Para i = 10 ate 1 Faca
 */
void zen_para(ZVarTable* t, const char* var,
              long inicio, long fim, long passo,
              ZLoopCallback cb, void* ctx);

/*
 * zen_loop_break — chama esta funcao dentro do callback para
 * interromper zen_enquanto ou zen_para antes do fim.
 * Internamente usa uma flag de contexto; nao usa setjmp/longjmp.
 */
typedef struct {
    int  parar;   /* sete como 1 para quebrar o loop */
    void* dados;  /* seus proprios dados de contexto */
} ZLoopCtx;

#endif
