#ifndef ZEN_MODULO_H
#define ZEN_MODULO_H

#include "runtime.h"
#include "zeniris_erro.h"

#define ZMM_MAX_MODULOS  64
#define ZMM_HASH_SIZE    128
#define ZMM_MAX_RAM_KB   512

typedef struct {
    char        nome[256];
    char        caminho[256];
    int         contagem_uso;
    long        ultimo_uso_ms;
    long        tamanho_bytes;
    int         dirty;
    NoPrograma* prog;
    Runtime*    rt;
} ZenModulo;

typedef struct {
    int indices[ZMM_MAX_MODULOS];
    int n;
} ZenGrupo;

typedef struct {
    ZenModulo modulos[ZMM_MAX_MODULOS];
    int       n_modulos;
    long      ram_usada_bytes;
    long      max_ram_bytes;
    int       tabela_hash[ZMM_HASH_SIZE];
    ZenGrupo  grupos[ZMM_MAX_MODULOS];
    int       n_grupos;
} ZenModuloManager;

void       zmm_init(ZenModuloManager* zmm, int max_ram_kb);
ZenModulo* zmm_registrar(ZenModuloManager* zmm, const char* nome, const char* caminho);
int        zmm_executar(ZenModuloManager* zmm, Runtime* rt_principal,
                        const char* nome_classe, const char* nome_function,
                        Idioma lang);
void       zmm_precarregar(ZenModuloManager* zmm, const char* nome_classe);
void       zmm_liberar_lru(ZenModuloManager* zmm);
void       zmm_dump(ZenModuloManager* zmm);

#endif
