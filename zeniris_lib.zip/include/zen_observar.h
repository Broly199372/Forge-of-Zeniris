#ifndef ZEN_OBSERVAR_H
#define ZEN_OBSERVAR_H

#include "runtime.h"
#include "zen_modulo.h"
#include "zeniris_erro.h"

#define MAX_OBSERVADOS 64

typedef struct {
    char nome[256];          /* nome da classe */
    char estados[16][256];   /* estados especificos ou vazio=todos */
    int  n_estados;
    char ultimo_valor[16][256];
} ZenObservado;

typedef struct {
    ZenObservado    observados[MAX_OBSERVADOS];
    int             n_observados;
    ZenModuloManager* zmm;
} ZenObserver;

int  zen_observer_carregar(ZenObserver* zo, const char* runtime_zn, ZenModuloManager* zmm, Idioma lang);
void zen_observer_tick(ZenObserver* zo, Runtime* rt);
void zen_observer_dump(ZenObserver* zo);

#endif
