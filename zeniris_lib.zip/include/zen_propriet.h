#ifndef ZEN_PROPRIET_H
#define ZEN_PROPRIET_H

#include "zeniris_erro.h"

typedef struct {
    char nomemod[256];
    char versao[64];
    char descricao[512];
    char autor[256];
    int  carregado;
} ZenPropriet;

ZenPropriet zen_propriet_ler(const char* caminho, Idioma lang);
void        zen_propriet_dump(ZenPropriet* p);
int         zen_propriet_validar(ZenPropriet* p, const char* arquivo, Idioma lang);

#endif
