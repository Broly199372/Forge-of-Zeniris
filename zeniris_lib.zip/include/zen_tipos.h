#ifndef ZEN_TIPOS_H
#define ZEN_TIPOS_H

typedef enum {
    ZTIPO_INDEFINIDO,
    ZTIPO_INT,
    ZTIPO_FLOAT,
    ZTIPO_BOOL
} ZTipo;

typedef struct {
    char   nome[256];
    ZTipo  tipo;
    long   val_int;
    double val_float;
    int    val_bool;
    char   val_str[256];
} ZVar;

typedef struct {
    ZVar vars[256];
    int  n;
} ZVarTable;

void   zvt_init(ZVarTable* t);
ZVar*  zvt_get(ZVarTable* t, const char* nome);
ZVar*  zvt_set_int(ZVarTable* t, const char* nome, long val);
ZVar*  zvt_set_float(ZVarTable* t, const char* nome, double val);
ZVar*  zvt_set_bool(ZVarTable* t, const char* nome, int val);
ZVar*  zvt_set_str(ZVarTable* t, const char* nome, const char* val);
ZTipo  zvt_inferir(const char* val_str);
void   zvt_dump(ZVarTable* t);

#endif
