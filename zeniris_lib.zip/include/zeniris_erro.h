#ifndef ZENIRIS_ERRO_H
#define ZENIRIS_ERRO_H

typedef enum {
    LANG_PT,
    LANG_EN,
    LANG_ES
} Idioma;

typedef struct {
    char arquivo[256];
    int  linha;
    char mensagem[512];
} ZenError;

Idioma   detectar_idioma(const char* codigo);
ZenError zen_erro(const char* arquivo, int linha, const char* tipo, const char* detalhe, Idioma lang);
void     zen_erro_print(ZenError* e);

#endif
